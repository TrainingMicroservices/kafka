package org.foundation;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.setProperty(org.slf4j.impl.SimpleLogger.DEFAULT_LOG_LEVEL_KEY, "off");
        productor();
        consumidor();
        System.out.println( "Hello World!" );
    }

    static public void productor(){
         String servidoresBootstrap = "localhost:9092";
        String topic = "TOPIC-HR-ALTAS";

        Properties props = new Properties();
        props.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, servidoresBootstrap);
        props.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());


        KafkaProducer<String, String> productor = new KafkaProducer<>(props);
        try {
            System.out.println("======================INICIO=============================");
            System.out.println("Mensaje enviado:"+productor.send(new ProducerRecord<>(topic, "clave","Un mensaje desde Java")));
            System.out.println("======================FIN=============================");
        } finally {
            productor.flush();
            productor.close();
        }

    }

    static public void consumidor(){
        String servidoresBootstrap = "localhost:9092";
        String topic = "TOPIC-HR-ALTAS";

        Properties props = new Properties();
        props.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, servidoresBootstrap);
        props.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.setProperty(ConsumerConfig.GROUP_ID_CONFIG, "miGrupoConsumidor");
        props.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.setProperty(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        //props.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");

        
        KafkaConsumer<String, String> consumidor = new KafkaConsumer<>(props);

        consumidor.seekToBeginning(consumidor.assignment());


        System.out.println("####################### A N T E S #######################");
        try {
            consumidor.subscribe(Collections.singleton(topic));

            ConsumerRecords<String, String> mensajes = consumidor.poll(Duration.ofSeconds(10));

            System.out.println("Total de Mensajes:"+mensajes.count());

            for (ConsumerRecord<String, String> mensaje: mensajes) {
                System.out.println("[CLAVE]:"+mensaje.value()+"\n"+
                                   "[VALOR]:"+mensaje.value());
            }
        } finally {
            consumidor.close();
        }
        
        System.out.println("####################### D E S P U E S #######################");

    }
}
